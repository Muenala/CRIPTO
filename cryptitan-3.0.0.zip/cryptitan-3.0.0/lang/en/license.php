<?php


return [
    'unavailable' => 'License server is unavailable.',
    'invalid'     => 'Invalid license.',
];