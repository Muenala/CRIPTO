<?php

return [
    'invalid_adapter' => 'The specified coin adapter is invalid.',
    'identifier_exists' => 'The coin identifier already exists.',
];
