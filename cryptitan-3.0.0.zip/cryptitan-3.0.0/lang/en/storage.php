<?php

return [
    'file_not_found' => 'The file no longer exists.',
];
