<?php

return [
    'whoops'      => 'Whoops!',
    'hello'       => 'Hello!',
    'regards'     => 'Regards',
    'action_info' => "If you're having trouble clicking the \":actionText\" button, copy and paste the URL below into your web browser:",
    'copyright' => 'All rights reserved.',
];
