<?php

return [
    'enable_demo' => (bool) env('COIN_MOCK_TOKEN', false),
];
